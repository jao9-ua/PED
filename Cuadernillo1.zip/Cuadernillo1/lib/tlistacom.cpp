#ifndef __TLISTACOM__
#define __TLISTACOM__

#include <iostream>
#include <sstream>
#include "tlistacom.h"

TListaNodo::TListaNodo()
{
    anterior = NULL;
    siguiente = NULL;
}

TListaNodo::TListaNodo(TListaNodo &n)
{
    e = n.e;
    anterior = n.anterior;
    siguiente = n.siguiente;
}

TListaNodo::~TListaNodo()
{
    e.~TComplejo();

    anterior = NULL;
    siguiente = NULL;
}

TListaNodo &TListaNodo::operator=(TListaNodo &d)
{
    if (this == &d)
    {
        return *this;
    }
    else
    {
        (*this).~TListaNodo();
        e = d.e;
        anterior = d.anterior;
        siguiente = d.siguiente;
        return *this;
    }
}

// TListaPos

TListaPos::TListaPos()
{
    pos=NULL;
}
TListaPos::TListaPos(const TListaPos &d)
{
    pos = d.pos;
}

TListaPos::~TListaPos()
{
    pos = NULL;
}

TListaPos &TListaPos::operator=(const TListaPos &d)
{
    if (this == &d)
    {
        return *this;
    }
    else
    {
        (*this).~TListaPos();
        pos=NULL;
        pos=d.pos;
        return *this;
    }
}

bool TListaPos::operator==(TListaPos &d)
{
    if(pos==d.pos)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool TListaPos::operator!=(TListaPos &d)
{
    return !(this->operator==(d));
}

TListaPos TListaPos::Anterior()
{
    TListaPos d;
    if(this->pos->anterior != NULL)
    {
        d.pos =pos->anterior;
    }
    return d;
}

TListaPos TListaPos::Siguiente()
{
    TListaPos d;
    if(this->pos->siguiente != NULL)
    {
        d.pos =pos->siguiente;
    }
    return d;
}

bool TListaPos::EsVacia()
{
     if(pos == NULL)
    {
        return true;
    }
    return false;
}

// TListaCom

TListaCom::TListaCom()
{
   primero = NULL;
   ultimo = NULL;
}

TListaCom::TListaCom(const TListaCom &d)
{
    primero=NULL;
    ultimo=NULL;
    TListaPos otro = d.Ultima();
    while(otro.EsVacia())
    {
        InsCabeza(otro.pos->e);

        otro=otro.Anterior();
    }

}

TListaCom::~TListaCom()
{
    TListaNodo *aux;

    while(this->primero != NULL)
    {
        aux = this->primero->siguiente;
        delete this->primero;
        this->primero=aux;
    }

}

TListaCom &TListaCom::operator=(TListaCom &d)
{
    if (this == &d)
    {
        return *this;
    }
    else
    {
        (*this).~TListaCom();
        //faltan cosas lo mismo que el constructor de copia
        return *this;
    }
}

bool TListaCom::operator==(TListaCom &d)
{
    while(primero !=NULL)
    {
        if(d.primero==NULL)
        {
            return false;
        }
        else
        {
            if(primero->e!=d.primero->e)
            {
                return false;
            }
            else
            {
                primero=primero->siguiente;
                d.primero=d.primero->siguiente;
            }
        }
    }
    return true;
}

bool TListaCom::operator!=(TListaCom &d)
{
    return !(*this == d);
}

TListaCom TListaCom::operator+(TListaCom &d)
{
    TListaCom res;
    while(primero!=ultimo)
    {
        res.primero=primero;
        res.primero=res.primero->siguiente;
        primero=primero->siguiente;
        
    }
    res.primero=res.primero->siguiente;
    res.primero=ultimo;
    while(d.primero!=d.ultimo)
    {
        res.primero=d.primero;
        res.primero=res.primero->siguiente;
        d.primero=d.primero->siguiente;
        
    }
    res.ultimo=d.ultimo;
    return res;
}

TListaCom TListaCom::operator-(TListaCom &d)
{
    TListaCom res;
    bool comprobar=true;
    while(primero!=ultimo)
    {
        for(TListaPos i=this->Primera();i.EsVacia();i=i.Siguiente())
        {
            if(primero==i.pos)
            {
                comprobar=false;
            }
        }
        if(comprobar)
        {
            res.primero=primero;
            primero=primero->siguiente;
        }
        else
        {
            primero=primero->siguiente;
            comprobar=true;
        }
    }

    return res;
}

bool TListaCom::EsVacia()
{
    if(primero==NULL)
    {
        return true;
    }
    return false;
}

bool TListaCom::InsCabeza(TComplejo &d)
{
    TListaNodo *aux=new TListaNodo();
    aux->e=d;
    if(EsVacia())
    {
         
        primero=aux;
        ultimo=primero;
        return true;
    }
    cout << "caca";
    while(primero->anterior!=NULL)
    {
        primero=primero->anterior;
    }
    if(true)
    {
        primero->e=d;
        return true;
    }
    else
    {
        return false;
    }
}

bool TListaCom::InsertarI(TComplejo &d, TListaPos &n)
{
    TListaNodo *aux;
    if(n.pos->anterior ==NULL || n.pos==NULL)
    {
        return false;
    }
    if(aux=new TListaNodo())
    {
        aux->e=d;
        aux->anterior=n.pos->anterior;
        aux->siguiente=n.pos;
        n.pos->anterior->siguiente=aux;
        n.pos->anterior=aux;

        return true;
    }
    else
    {
        return false;
    }
}

bool TListaCom::InsertarD(TComplejo &d, TListaPos &n)
{
    TListaNodo *aux;
    if(n.pos==NULL)
    {
        return false;
    }
    if(aux=new TListaNodo())
    {
        aux->e=d;
        aux->siguiente=n.pos->siguiente;
        aux->anterior=n.pos;
        n.pos->siguiente->anterior=aux;
        n.pos->siguiente=aux;
        return true;
    }
    else
    {
        return false;
    }
}

bool TListaCom::Borrar(TComplejo &d)
{
    TListaNodo *aux;
    while(primero!=NULL)
    {
        if(primero->e==d)
        {
            aux=primero;
            if(primero->anterior!=NULL && primero->siguiente!=NULL)
            {
                aux = primero;
                primero->anterior->siguiente=primero->siguiente;
                primero->siguiente->anterior=primero->anterior;
                delete aux;
                return true;
            }
            else if(primero->anterior==NULL)
            {
                aux=primero;
                primero->siguiente->anterior==NULL;
                primero->siguiente==NULL;
                delete aux;
                return true;
            }
        }

    }
    return false;
}

bool TListaCom::BorrarTodos(TComplejo &d)
{
    bool sol=true;
    while(1)
    {
        if(sol && Borrar(d))
        {
            sol=false;
        }
        if(Borrar(d))
        {
            return true;
        }
    }
}

bool TListaCom::Borrar(TListaPos &d)
{
    TListaNodo *aux;
    while(!EsVacia())
    {
        if(primero==d.pos)
        {
            aux=primero;
            primero->anterior->siguiente=primero->siguiente;
            primero->siguiente->anterior=primero->anterior;
            delete aux;
            return true;
        }
        else
        {
            primero=primero->siguiente;
        }
    }
    return false;
}

TComplejo TListaCom::Obtener(TListaPos &d)
{
    return d.pos->e;
}

bool TListaCom::Buscar(TComplejo &d)
{
    for(TListaPos i=Primera(); !i.EsVacia();i=i.Siguiente())
    {
        if(Obtener(i)==d)
        {
            return true;
        }
    }
    return false;
}

int TListaCom::Longitud() const
{
    int cont=0;
    for(TListaPos i= Primera(); !i.EsVacia();i=i.Siguiente())
    {
        cont++;
    }
    return cont;
}

TListaPos TListaCom::Primera() const
{
    TListaPos tpos;
    if(this->primero == NULL)
        return tpos;
    else{
        tpos.pos = this->primero;
        return tpos; 
    }
}

TListaPos TListaCom::Ultima() const
{
    TListaPos tpos;
    tpos.pos=ultimo;
    return tpos;
    
}

ostream &operator<<(ostream &os, TListaCom &d)
{
    os << "{";
    for (TListaPos i = d.Primera(); !i.EsVacia(); i=i.Siguiente())
    {
        if(!i.EsVacia())
        {
            os << d.Obtener(i);
        }
        
    }
    os << "}";

    return os;
}

#endif